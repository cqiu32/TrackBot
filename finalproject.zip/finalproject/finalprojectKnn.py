import numpy as np
from sklearn.neighbors import KNeighborsRegressor
import os, sys
import pickle as pickle
from sklearn.externals import joblib
import math as math
import matplotlib.pyplot as plt

################## UTILITIES ####################################

NUM_FRAMES_TO_PREDICT = 60

def readFile(path):
    f =open(path)
    return np.loadtxt(f, delimiter = ",");

def getNextSteps(numberOfSteps, data, curIndex):
    stepsX = []
    stepsY = []
    for index in range(curIndex, curIndex+numberOfSteps):
        stepsX.append(data[index][0])
        stepsY.append(data[index][1])
    return (stepsX, stepsY)        

def createNextStepsMap(data):
    mapX = dict()
    mapY = dict()
    
    for i in range(len(data) - NUM_FRAMES_TO_PREDICT):
        x = data[i][0]
        y = data[i][1]
        (stepsX, stepsY) = getNextSteps(NUM_FRAMES_TO_PREDICT, data, i)
        mapX[x] = stepsX
        mapX[y] = stepsY
    return (mapX, mapY)

def createFeaturesAndLabels(data):
    features = []
    for i in range(len(data) - NUM_FRAMES_TO_PREDICT):
       current = data[i]
       (stepsX, stepsY) = getNextSteps(NUM_FRAMES_TO_PREDICT, data, i)
       if i == 0:
           features.append([current[0], current[1], 0, 0, 0, stepsX, stepsY])
       else:
           prev = data[i-1]
           velocity = getVelocity(current, prev)
           heading = calculateHeading(current, prev)
           features.append([current[0], current[1], velocity[0], velocity[1], heading, stepsX, stepsY])
    return features

def createFeatures(data):
    features = []
    for i in range(len(data) - NUM_FRAMES_TO_PREDICT):
       current = data[i]
       
       if i == 0:
           features.append([current[0], current[1], 0, 0, 0])
       else:
           prev = data[i-1]
           velocity = getVelocity(current, prev)
           heading = calculateHeading(current, prev)
           features.append([current[0], current[1], velocity[0], velocity[1], heading])
    return features

def getVelocity(current, prev):
    return (30 * (current[0] - prev[0]), 30 * (current[1] - prev[1]))
    
    
def angle_trunc(a):
    """This maps all angles to a domain of [-pi, pi]"""
    while a < 0.0:
        a += math.pi * 2
    return ((a + math.pi) % (math.pi * 2)) - math.pi
    
def calculateHeading(current, prev):
    heading = math.atan2(current[1] - prev[1], current[0] - prev[0])
    heading = angle_trunc(heading)
    return heading

def error(l1, l2):
    return sum((c - a)**2 + (d - b)**2 for ((a, b), (c, d)) in zip(l1, l2))**0.5  

def plotLine(arr1, label1):
    plt.plot(arr1)
    plt.legend(labels = [label1])
    plt.show() 

def plotGraph(arr1, arr2, label1, label2):
   plt.plot(np.array(arr1)[:,0], np.array(arr1)[:,1], 'ro')
   plt.axis([0,600, 0,600])
   
   plt.plot(np.array(arr2)[:,0], np.array(arr2)[:,1], 'bo')
   plt.legend(labels = [label1, label2])
   plt.show()     
   
def saveModel(model, path):
    # save the classifier
    with open(path + '.pkl', 'wb') as fid:
        pickle.dump(model, fid)    

def loadModel(path):
    # load the model
    with open(path + '.pkl', 'rb') as fid:
        model = pickle.load(fid)
        return model
################## UTILITIES ####################################

n_neighbors = 10
modelPathX = "model/knnX";
modelPathY = "model/knnY";


predictions = []

# Load model 
modelX = loadModel(modelPathX)
modelY = loadModel(modelPathY)
   
testFilePath = sys.argv[1]

# Read test data
testdata = readFile(testFilePath)

LAST_ROW_INDEX = len(testdata) - 1

# Create features for all rows
testFeaturesAndLabels = createFeatures(testdata)

testFeatureData = [ [row[0], row[1], row[2], row[3], row[4]] for row in testFeaturesAndLabels]

# select last row to predict next 60 frames
lastRowFeature = np.array(testFeatureData[LAST_ROW_INDEX])
lastRowFeature = lastRowFeature.reshape(1, -1)

# make predictions via model and capture results
predictionsX = modelX.predict(lastRowFeature)[0]
predictionsY = modelY.predict(lastRowFeature)[0]     

predictions = zip(predictionsX, predictionsY)

# save the predictions
np.savetxt('prediction.txt' , predictions, delimiter=',', fmt='%d'); 


        
